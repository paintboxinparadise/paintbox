// src/pages/Fall.js
import React from 'react';
import Gallery from '../components/Fall/FallGallery';

const Fall = () => {
    return (
        <div className="bg-gray-50 min-h-screen">
            <h1 className="text-4xl font-bold text-center py-8 text-gray-800">Fall Collection</h1>
            <Gallery />
        </div>
    );
};

export default Fall;
