// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './Pages/Homepage';
import About from './Pages/About';
import Fall from './Pages/Fall'

const App = () => {
    return (
        <Router>
            <Layout>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/fall" element={<Fall />} />
                </Routes>
            </Layout>
        </Router>
    );
};

export default App;
