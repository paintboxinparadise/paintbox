import React from 'react';
import Gallery from './Gallery';

const KidsGallery = () => {
    return (
        <div>
            <Gallery />
        </div>
    );
};

export default KidsGallery;
