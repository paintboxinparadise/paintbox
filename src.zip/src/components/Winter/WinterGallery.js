import React from 'react';
import Gallery from './Gallery';

const WinterGallery = () => {
    return (
        <div>
            <Gallery />
        </div>
    );
};

export default WinterGallery;
