import React from 'react';
import Gallery from './Gallery';
import NewYears from './NewYears';

const WinterGallery = () => {
    return (
        <div>
            <Gallery />
            <NewYears />
        </div>
    );
};

export default WinterGallery;
