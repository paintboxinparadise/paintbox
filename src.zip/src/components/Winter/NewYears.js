// src/Pages/NewYears.js
import React from 'react';
import { motion } from 'framer-motion';
import Gallery from './NewYearsGallery';

const NewYears = () => {
    return (
        <div className="bg-gradient-to-b from-gray-900 via-black to-gray-800 min-h-screen">
            {/* Animated Header with Floating Fireworks */}
            <div className="relative w-full h-auto overflow-hidden">
                {[...Array(15)].map((_, i) => (
                    <motion.div
                        key={i}
                        className="absolute text-yellow-400"
                        style={{
                            top: `${Math.random() * 100}%`, // Random vertical position
                            left: `${Math.random() * 100}%`, // Random horizontal position
                            fontSize: `${Math.random() * 2 + 1.5}rem`, // Random font size for variation
                        }}
                        initial={{
                            scale: 0,
                            opacity: 0,
                        }}
                        animate={{
                            scale: [0, 1.2, 1], // Simulate fireworks explosion
                            opacity: [0, 1, 0], // Fade in and out
                        }}
                        transition={{
                            duration: Math.random() * 2 + 1, // Randomized explosion duration
                            repeat: Infinity,
                            delay: Math.random() * 2, // Staggered appearance
                        }}
                    >
                        🎆
                    </motion.div>
                ))}

                <motion.h1
                    className="text-5xl font-extrabold text-center py-8 text-yellow-400"
                    initial={{ opacity: 0, y: -50 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 1, ease: 'easeOut' }}
                >
                    🎆 New Year Celebration 🎆
                </motion.h1>
            </div>

            {/* Gallery */}
            <Gallery />
        </div>
    );
};

export default NewYears;
