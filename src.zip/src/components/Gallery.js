// src/components/Gallery.js
import React from 'react';
import PropTypes from 'prop-types';

const Gallery = ({ images = [] }) => {
    return (
        <div className="overflow-x-auto whitespace-nowrap py-6 px-4">
            <div className="flex gap-4">
                {images.map((image, index) => (
                    <img
                        key={index}
                        src={image.src}
                        alt={image.alt || `Painting ${index + 1}`}
                        className="w-72 h-72 object-cover rounded-lg shadow-lg hover:scale-105 transition-transform"
                    />
                ))}
            </div>
        </div>
    );
};

// Prop validation
Gallery.propTypes = {
    images: PropTypes.arrayOf(
        PropTypes.shape({
            src: PropTypes.string.isRequired,
            alt: PropTypes.string,
        })
    ),
};

export default Gallery;
