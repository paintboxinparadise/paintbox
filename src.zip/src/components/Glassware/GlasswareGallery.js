import React from 'react';
import Gallery from './Gallery';

const GlasswareGallery = () => {
    return (
        <div>
            <Gallery />
        </div>
    );
};

export default GlasswareGallery;
