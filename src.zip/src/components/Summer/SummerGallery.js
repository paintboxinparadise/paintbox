import React from 'react';
import Gallery from './Gallery';

const SummerGallery = () => {
    return (
        <div>
            <Gallery />
        </div>
    );
};

export default SummerGallery;
