import React from 'react';
import Gallery from './Gallery';

const MiscGallery = () => {
    return (
        <div>
            <Gallery />
        </div>
    );
};

export default MiscGallery;
