// src/pages/Fall.js
import React from 'react';
import Gallery from '../Gallery';
import Image1 from '../../Assets/Images/Fall/fall1.jpg'
import Image2 from '../../Assets/Images/Fall/fall2.jpg'
import Image3 from '../../Assets/Images/Fall/fall3.jpg'

const fallPaintings = [
    { src: Image1, alt: 'Fall Painting 1' },
    { src: Image2, alt: 'Fall Painting 2' },
    { src: Image3, alt: 'Fall Painting 3' },
];

const Fall = () => {
    return (
            <div className="bg-gray-50 min-h-screen">
                <h1 className="text-4xl font-bold text-center py-8 text-gray-800">Fall Collection</h1>
                <Gallery images={fallPaintings} />
            </div>
    );
};

export default Fall;
