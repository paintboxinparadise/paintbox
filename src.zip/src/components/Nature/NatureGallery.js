import React from 'react';
import Gallery from './Gallery';

const NatureGallery = () => {
    return (
        <div>
            <Gallery />
        </div>
    );
};

export default NatureGallery;
