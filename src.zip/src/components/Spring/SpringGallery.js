import React from 'react';
import Gallery from './Gallery';

const SpringGallery = () => {
    return (
        <div>
            <Gallery />
        </div>
    );
};

export default SpringGallery;
