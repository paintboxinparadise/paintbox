// src/components/Homepage/Navbar.js
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import logo from '../Assets/Images/logo.png';
import { motion } from 'framer-motion';

const Navbar = () => {
    const [isOpen, setIsOpen] = useState(false);
    const location = useLocation();

    const splatters = [
        { top: '10%', left: '15%', bgColor: '#FF69B4' },
        { top: '30%', left: '50%', bgColor: '#FFD700' },
        { top: '70%', left: '20%', bgColor: '#1E90FF' },
        { top: '50%', left: '80%', bgColor: '#32CD32' },
        { top: '90%', left: '40%', bgColor: '#FF4500' },
    ];

    return (
        <motion.nav
            className="bg-white shadow-md sticky top-0 z-50 relative overflow-hidden"
            initial="hidden"
            animate="visible"
        >
            <div className="container mx-auto px-6 md:px-12 lg:px-20 flex items-center justify-between py-4">
                {/* Logo */}
                <div className="flex items-center space-x-2">
                    <img src={logo} alt="Logo" className="h-16 w-16" />
                </div>

                {/* Navigation Links */}
                <div className="hidden md:flex space-x-8 justify-center flex-1">
                    <Link
                        to="/"
                        className={`${
                            location.pathname === "/" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        HOME
                    </Link>
                    <Link
                        to="/about"
                        className={`${
                            location.pathname === "/about" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        ABOUT
                    </Link>
                    <Link
                        to="/fall"
                        className={`${
                            location.pathname === "/fall" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        FALL
                    </Link>
                    <Link
                        to="/winter"
                        className={`${
                            location.pathname === "/winter" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        WINTER
                    </Link>
                    <Link
                        to="/spring"
                        className={`${
                            location.pathname === "/spring" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        SPRING
                    </Link>
                    <Link
                        to="/summer"
                        className={`${
                            location.pathname === "/summer" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        SUMMER
                    </Link>
                    <Link
                        to="/nature"
                        className={`${
                            location.pathname === "/nature" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        NATURE
                    </Link>
                    <Link
                        to="/animals"
                        className={`${
                            location.pathname === "/animals" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        ANIMALS
                    </Link>
                    <Link
                        to="/glassware"
                        className={`${
                            location.pathname === "/glassware" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        GLASSWARE
                    </Link>
                    <Link
                        to="/kids"
                        className={`${
                            location.pathname === "/kids" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        KIDS
                    </Link>
                    <Link
                        to="/misc"
                        className={`${
                            location.pathname === "/misc" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                        } transition`}
                    >
                        MISC
                    </Link>
                </div>

                {/* Hamburger Menu */}
                <button
                    className="block md:hidden text-pink-500 focus:outline-none"
                    onClick={() => setIsOpen(!isOpen)}
                >
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M4 6h16M4 12h16m-7 6h7"
                        />
                    </svg>
                </button>

                {/* Mobile Menu */}
                {isOpen && (
                    <div className="absolute top-16 left-0 w-full bg-white shadow-lg md:hidden">
                        <div className="flex flex-col space-y-4 px-6 py-4">
                            <Link
                                to="/"
                                className={`${
                                    location.pathname === "/" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                HOME
                            </Link>
                            <Link
                                to="/about"
                                className={`${
                                    location.pathname === "/about" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                ABOUT
                            </Link>
                            <Link
                                to="/fall"
                                className={`${
                                    location.pathname === "/fall" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                FALL
                            </Link>
                            <Link
                                to="/winter"
                                className={`${
                                    location.pathname === "/winter" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                WINTER
                            </Link>
                            <Link
                                to="/spring"
                                className={`${
                                    location.pathname === "/spring" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                SPRING
                            </Link>
                            <Link
                                to="/summer"
                                className={`${
                                    location.pathname === "/summer" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                SUMMER
                            </Link>
                            <Link
                                to="/nature"
                                className={`${
                                    location.pathname === "/nature" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                NATURE
                            </Link>
                            <Link
                                to="/animals"
                                className={`${
                                    location.pathname === "/animals" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                ANIMALS
                            </Link>
                            <Link
                                to="/glassware"
                                className={`${
                                    location.pathname === "/glassware" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                GLASSWARE
                            </Link>
                            <Link
                                to="/kids"
                                className={`${
                                    location.pathname === "/kids" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                KIDS
                            </Link>
                            <Link
                                to="/misc"
                                className={`${
                                    location.pathname === "/misc" ? "text-pink-500 font-bold" : "text-black hover:text-pink-300"
                                } transition`}
                                onClick={() => setIsOpen(false)}
                            >
                                MISC
                            </Link>
                        </div>
                    </div>
                )}
            </div>

            {/* Paint Splatter Animation */}
            {splatters.map((splatter, index) => (
                <motion.div
                    key={index}
                    className="absolute rounded-full blur-xl"
                    style={{
                        top: splatter.top,
                        left: splatter.left,
                        width: '70px',
                        height: '70px',
                        backgroundColor: splatter.bgColor,
                        zIndex: -1,
                    }}
                    initial="hidden"
                    animate="visible"
                ></motion.div>
            ))}
        </motion.nav>
    );
};

export default Navbar;
