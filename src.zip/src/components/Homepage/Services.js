// src/components/Homepage/Services.js
import React from 'react';

const services = [
    {
        id: 1,
        title: 'What we Provide',
        description: 'We provide all necessary materials, setup, and lessons. No experience is required, and everyone leaves with a masterpiece. Hosts only need to provide the venue, food, and drinks.',
        icon: '💡',
    },
    {
        id: 2,
        title: 'Pricing',
        description: 'Private parties start at $30 per person with a 10-person minimum. Additional charges apply for extended time and customized paintings.',
        icon: '🎨',
    },
];

const Services = () => {
    return (
        <section id="services" className="bg-gray-50 py-16">
            <div className="container mx-auto px-6 md:px-12 lg:px-20 text-center">
                <h2 className="text-3xl font-extrabold text-gray-800 mb-8">Our Services</h2>

                <div className="grid gap-8 md:grid-cols-1 lg:grid-cols-2">
                    {services.map((service) => (
                        <div
                            key={service.id}
                            className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow mx-auto"
                        >
                            <div className="text-5xl mb-4">{service.icon}</div>
                            <h3 className="text-xl font-semibold text-gray-800 mb-2">
                                {service.title}
                            </h3>
                            <p className="text-gray-600 text-left">{service.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Services;
