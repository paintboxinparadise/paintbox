// src/components/Homepage/Reviews.js
import React from 'react';
import KathyThomasReview from '../../Assets/Images/KathyThomasReview.jpeg';
import TamaraMickelson from '../../Assets/Images/TamaraMickelson.jpg';
import KarenRowe from '../../Assets/Images/KarenRowe.jpeg';

const Reviews = () => {
    const reviews = [
        {
            id: 1,
            name: 'Kathy Thomas',
            image: KathyThomasReview,
            text: 'Excellent service! I highly recommend them to anyone looking for professional and friendly help.',
        },
        {
            id: 2,
            name: 'Tamara Mickelson',
            image: TamaraMickelson,
            text: 'Truly outstanding! They went above and beyond to ensure our satisfaction.',
        },
        {
            id: 3,
            name: 'Karen Rowe',
            image: KarenRowe,
            text: 'Last night was our first time with Paintbox in Paradise. What a fun night! Plenty of instruction and encouragement from Amanda..',
        },
    ];

    return (
        <section id="reviews" className="bg-gray-50 py-16">
            <div className="container mx-auto px-6 md:px-12 lg:px-20">
                <h2 className="text-3xl font-extrabold text-gray-800 text-center mb-8">
                    What Our Clients Say
                </h2>

                <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                    {reviews.map((review) => (
                        <div
                            key={review.id}
                            className="bg-white p-6 rounded-lg shadow-lg text-center flex flex-col items-center"
                        >
                            <img
                                src={review.image}
                                alt={review.name}
                                className="w-24 h-24 rounded-full mb-4"
                            />
                            <h3 className="text-lg font-semibold text-gray-800">{review.name}</h3>
                            <p className="text-gray-600 mt-4">"{review.text}"</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Reviews;
